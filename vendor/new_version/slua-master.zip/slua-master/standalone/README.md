
slua has no UnityEngine.dll dependency


Windows
=============
double click the premake-slua-standalone.bat to refresh all the projects