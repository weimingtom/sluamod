
using SLua;

class MainClass
{

    static void Main(string[] args)
    {
        var luaState = new LuaState();
        int i;
        i = 0;
    }
}