## Run tests
* export namespace "NLuaTest.Mock" (uncomment in CustomExport.cs::OnAddCustomNamespace)
* Slua -> Custom -> make
* run test.unity